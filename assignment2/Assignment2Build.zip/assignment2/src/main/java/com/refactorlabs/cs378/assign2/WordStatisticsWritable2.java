package com.refactorlabs.cs378.assign2;

public class WordStatisticsWritable2 {

}
